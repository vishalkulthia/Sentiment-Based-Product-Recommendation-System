import flask
from flask import Flask, request, render_template
import numpy as np
import pickle
import json
import pandas as pd
import joblib
import requests
# Create Flask object to run
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    if (request.method=='POST'):
        print('hi')
        user_id=[x for x in request.form.values()]
        user_id=[np.array(user_id)]
        user_id=user_id[0][0]
        review_data = pd.DataFrame(pickle.load(open('review_data_dict.pkl', 'rb')))
        user_rating = pd.DataFrame(pickle.load(open('user_final_rating_dict.pkl', 'rb')))
        clf1 = joblib.load('sentiments_model.pkl')
        cnt_vect = joblib.load('count_vectorizer.pkl')
        user_id=review_data[review_data['reviews_username']==user_id].iloc[0]['user_id']
        d = user_rating.loc[user_id].sort_values(ascending=False)[0:20]
        d = d.reset_index()
        d.columns = ['product_id', 'predicted_rating']
        review_data = review_data[review_data['product_id'].isin(d['product_id'].tolist())]
        x_test, y_test = review_data['cleaned_reviews'], review_data['user_sentiment']
        x_test_features = cnt_vect.transform(x_test)
        y_test_pred = clf1.predict(x_test_features)
        review_data['predicted_sentiment'] = list(y_test_pred)
        review_data.predicted_sentiment = review_data.predicted_sentiment.astype('int')
        result=review_data.groupby('product_id')['predicted_sentiment'].sum().reset_index().sort_values(by=['predicted_sentiment'],
                                                                                           ascending=False)[0:5]
        result=review_data[review_data['product_id'].isin(result['product_id'].to_list())][['name']].drop_duplicates().iloc[:]['name'].tolist()
        temp = []
        for i in range(len(result)):
            temp.append('Product'+" "+str(i+1)+ " : "+result[i])
        result=" ".join(temp)
        print(result)
        return render_template('index.html',prediction_text= result)
    else:
        return render_template('index.html')

@app.route('/predict-api',methods=['POST','GET'])
def predict_api():
    print("request.method:", request.method)
    if (request.method=='POST'):
        user_id=request.get_json()
        user_id=user_id['user_id']
        print("user id is",user_id)
        review_data = pd.DataFrame(pickle.load(open('review_data_dict.pkl', 'rb')))
        user_rating = pd.DataFrame(pickle.load(open('user_final_rating_dict.pkl', 'rb')))
        clf1 = joblib.load('sentiments_model.pkl')
        cnt_vect = joblib.load('count_vectorizer.pkl')
        print(user_id)
        user_id = review_data[review_data['reviews_username'] == user_id].iloc[0]['user_id']
        print(user_id)
        d = user_rating.loc[user_id].sort_values(ascending=False)[0:20]
        d = d.reset_index()
        d.columns = ['product_id', 'predicted_rating']
        review_data = review_data[review_data['product_id'].isin(d['product_id'].tolist())]
        x_test, y_test = review_data['cleaned_reviews'], review_data['user_sentiment']
        x_test_features = cnt_vect.transform(x_test)
        y_test_pred = clf1.predict(x_test_features)
        review_data['predicted_sentiment'] = list(y_test_pred)
        review_data.predicted_sentiment = review_data.predicted_sentiment.astype('int')
        result = review_data.groupby('product_id')['predicted_sentiment'].sum().reset_index().sort_values(
            by=['predicted_sentiment'],
            ascending=False)[0:5]
        result = review_data[review_data['product_id'].isin(result['product_id'].to_list())][['name']].drop_duplicates().iloc[:][
            'name'].tolist()
        temp = []
        for i in range(len(result)):
            temp.append('Product' + " " + str(i + 1) + " : " + result[i])
        result = " ".join(temp)
        print(result)
        print(json.dumps(result))
        return (json.dumps(result))

if __name__ == "__main__":
    # Start Application
    app.run()